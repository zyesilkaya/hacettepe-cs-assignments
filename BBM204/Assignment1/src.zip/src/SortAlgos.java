

public abstract class SortAlgos {

    abstract int[] sort(int[] arr);

}
