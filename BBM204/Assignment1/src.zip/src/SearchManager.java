import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

public class SearchManager extends Manager {

    void searchManager(SearchAlgos algo1, SearchAlgos algo2, String csvFilename, InputType inputType) throws IOException {

        fileName = csvFilename;

        result.clear();
        arrayList = result;

        for(int i:inputSizes) runXtimes(1000,i,algo1,inputType);

        System.out.println("--------IKINCI--------");

        result2.clear();
        arrayList = result2;

        for(int i:inputSizes) runXtimes(1000,i,algo2,inputType);
        System.out.println("--------UCUNCU--------");

        result3.clear();
        arrayList = result3;

        for(int i:inputSizes) runXtimes(1000,i,algo1,InputType.random);

    }


    void runXtimes(int runTime, int inputSize, SearchAlgos algorithm, InputType inputType) throws IOException {

        long total=0;
        int[] arr;

        for(int j=0;j<runTime;j++) {

            arr = Reader.fileReader(inputSize,fileName);

            int num = new Random().nextInt(arr.length);

            if(inputType == InputType.sorted || inputType == InputType.reversed) Arrays.sort(arr);

            if(inputType == InputType.reversed) Collections.reverse(Arrays.asList(arr));

            long startTime = System.nanoTime();

            algorithm.search(arr,arr[num]);

            long stopTime = System.nanoTime();

            long elapsedTime = stopTime - startTime;

            total += elapsedTime;

            System.out.println("SEARCH TIME:::::: "+elapsedTime);
        }

        arrayList.add((double)total/runTime);
    }
}
