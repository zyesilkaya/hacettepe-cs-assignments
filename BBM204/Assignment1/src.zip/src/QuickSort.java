

public class QuickSort extends SortAlgos{

    int[] sort(int[] arr){
        int low=0;
        int high=arr.length-1;
        int[] stack = new int[-low+high+1];
        int top=-1;
        stack[++top] = low;
        stack[++top] = high;
        while (top>=0){
            high = stack[top--]; //pop
            low = stack[top--];
            int pivot = partition(arr,low,high);

            if(pivot-1>low){ //that checks if there exist a left side of the array
                stack[++top] = low; //push
                stack[++top] = pivot-1;
            }

            if(pivot+1<high){ //that checks if there exist a right side of the array
                stack[++top] = pivot+1;
                stack[++top] = high; //push
            }

        }
        return arr;
    }

    int partition(int[] arr, int low, int high){
        int pivot = arr[high];
        int i = low - 1;

        for(int j=low;j<high;j++){
            if(arr[j] <= pivot){
                i++;
                int temp = arr[i];//swap
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        int temp = arr[i+1];//swap
        arr[i+1] = arr[high];
        arr[high] = temp;

        return i+1;
    }
}
