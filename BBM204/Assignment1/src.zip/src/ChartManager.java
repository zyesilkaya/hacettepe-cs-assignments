import org.knowm.xchart.*;
import org.knowm.xchart.style.Styler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class ChartManager {

    void createChart(String[] charts) throws IOException {

        // X axis data
        int[] inputAxis = {512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072, 251282};

        // Create sample data for linear runtime
        double[][] yAxis = new double[3][10];
        yAxis[0] = Arrays.stream(SortManager.result.toArray()).mapToDouble(o -> (double)o).toArray();
        yAxis[1] = Arrays.stream(SortManager.result2.toArray()).mapToDouble(o -> (double)o).toArray();
        yAxis[2] = Arrays.stream(SortManager.result3.toArray()).mapToDouble(o -> (double)o).toArray();

        // Save the char as .png and show it
        showAndSaveChart(charts[0], inputAxis, yAxis, charts);
    }

    public static void showAndSaveChart(String title, int[] xAxis, double[][] yAxis,String[] charts) throws IOException {
        // Create Chart
        XYChart chart = new XYChartBuilder().width(800).height(600).title(title)
                .yAxisTitle("Time in Milliseconds").xAxisTitle("Input Size").build();

        // Convert x axis to double[]
        double[] doubleX = Arrays.stream(xAxis).asDoubleStream().toArray();

        // Customize Chart
        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNE);
        chart.getStyler().setDefaultSeriesRenderStyle(XYSeries.XYSeriesRenderStyle.Line);

        // Add a plot for a sorting algorithm
        for(int i=1;i<charts.length;i++){
            chart.addSeries(charts[i], doubleX, yAxis[i-1]);
        }

        // Save the chart as PNG
        BitmapEncoder.saveBitmap(chart, title + ".png", BitmapEncoder.BitmapFormat.PNG);

        // Show the chart
        new SwingWrapper(chart).displayChart();
    }
}
