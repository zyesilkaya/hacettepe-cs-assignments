
public class BinarySearch extends SearchAlgos{

    int search(int[] arr, int x){

        int l=0;
        int r=arr.length-1;

        while (l<=r){

            int m = (r+l)/2;
            if(arr[m] == x) return m;
            else if(arr[m]<x) l=m+1;
            else if(arr[m]>x) r=m-1;

        }
        return -1;
    }
}
