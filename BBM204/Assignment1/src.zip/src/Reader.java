import java.io.BufferedReader;
import java.io.IOException;

public class Reader {

    static int[] fileReader(int inputSize, String fileName) throws IOException {

        int[] arr = new int[inputSize];

        String line;

        BufferedReader br = new BufferedReader(new java.io.FileReader(fileName));
        br.readLine();

        for(int i=0;i<inputSize;i++) {
            if((line = br.readLine()) != null){
                String[] cols = line.split(",");
                arr[i] = Integer.parseInt((cols[6]));
            }
        }
        return arr;
    }

}
