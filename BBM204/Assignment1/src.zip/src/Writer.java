import java.io.FileWriter;
import java.io.IOException;

public class Writer {

    void write(String fileName) throws IOException {

        FileWriter writer = new FileWriter(fileName);

        writer.write(Manager.result.toString());

        writer.write(Manager.result2.toString());

        writer.write(Manager.result3.toString());

        writer.close();

    }

}
