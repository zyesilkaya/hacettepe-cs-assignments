public abstract class SearchAlgos {
    abstract int search(int[] arr, int x);
}
