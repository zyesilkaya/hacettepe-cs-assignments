

import java.util.*;
import java.util.stream.IntStream;

public class BucketSort extends SortAlgos{

    int[] sort(int[] arr){

        int n = (int)Math.sqrt(arr.length);

        int m = arr[0];
        for (int num:arr){
            m = Math.max(num,m);
        }

        final int max = m;

        Map<Integer, List<Integer>> buckets = new HashMap<>();

        IntStream.range(0,n).forEach(i -> buckets.put(i, new ArrayList<>()));//create buckets

        for(int num:arr){
            buckets.get(hash(num,max,n)).add(num);//add numbers to the buckets
        }

        buckets.values().forEach(Collections::sort);//sort the buckets

        return Arrays.stream(buckets.values().stream().flatMap(Collection::stream).toArray()).mapToInt(o -> (int)o).toArray();//merge elements and return
    }

    int hash(int i, int max, int numOfBuckets){
        return i/max *(numOfBuckets-1);
    }

}
