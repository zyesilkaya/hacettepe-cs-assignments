
import org.knowm.xchart.*;
import org.knowm.xchart.style.Styler;

import java.io.*;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

class Main {

     public static void main(String args[]) throws IOException {

        //String csvFileName = args[0];

        String csvFileName = "C:\\Users\\zeynep\\SortAssignment\\src\\TrafficFlowDataset.csv";

        Writer writer = new Writer();

        SortManager sortManager = new SortManager();

        ChartManager chartManager = new ChartManager();

        SearchManager searchManager = new SearchManager();

        sortManager.sortManager(new QuickSort(),new BucketSort(),new SelectionSort(), csvFileName, InputType.random);

        chartManager.createChart(new String[]{"Sort Algorithms(random input)", "QuickSort","BucketSort", "SelectionSort"});

        writer.write("sort_algos_random_input.txt");

        sortManager.sortManager(new QuickSort(),new BucketSort(),new SelectionSort(), csvFileName, InputType.sorted);

        chartManager.createChart(new String[]{"Sort Algorithms(sorted input)", "QuickSort","BucketSort", "SelectionSort"});

        writer.write("sort_algos_sorted_input.txt");

        sortManager.sortManager(new QuickSort(),new BucketSort(),new SelectionSort(), csvFileName, InputType.reversed);

        chartManager.createChart(new String[]{"Sort Algorithms(reversed sorted input)", "QuickSort","BucketSort", "SelectionSort"});

        writer.write("sort_algos_reversed_input.txt");

        searchManager.searchManager(new LinearSearch(), new BinarySearch(),csvFileName, InputType.sorted);

        chartManager.createChart(new String[]{"Search Algorithms", "LinearSearch(sorted)","BinarySearch", "LinearSearch(unsorted)"});

        writer.write("search_algos.txt");

    }

}
