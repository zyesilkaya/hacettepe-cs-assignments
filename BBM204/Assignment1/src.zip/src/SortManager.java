import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.*;

enum InputType {
    random,
    sorted,
    reversed
}

public class SortManager extends Manager{


    void sortManager(SortAlgos algo1, SortAlgos algo2, SortAlgos algo3, String csvFilename, InputType inputType) throws IOException {

        fileName = csvFilename;

        result.clear();
        arrayList = result;

        for(int i:inputSizes) {
            runXtimes(10,i,algo1,inputType);
        }

        System.out.println("--------IKINCI--------");

        result2.clear();
        arrayList = result2;

        for(int i:inputSizes) runXtimes(10,i,algo2,inputType);

        System.out.println("--------UCUNCU--------");

        result3.clear();
        arrayList = result3;

        for(int i:inputSizes) runXtimes(10,i,algo3,inputType);

    }


    void runXtimes(int runTime, int inputSize, SortAlgos algorithm, InputType inputType) throws IOException {

        long total=0;
        int[] arr;
        for(int j=0;j<runTime;j++) {

            arr = Reader.fileReader(inputSize,fileName);

            if(inputType == InputType.sorted || inputType == InputType.reversed) Arrays.sort(arr);

            if(inputType == InputType.reversed) {

                for(int i=0; i<inputSize/2; i++) {
                    int temp = arr[i];
                    arr[i] = arr[inputSize-i-1];
                    arr[inputSize-i-1] = temp;
                }

            }

            long startTime = System.currentTimeMillis();

            arr = algorithm.sort(arr);

            long stopTime = System.currentTimeMillis();

            long elapsedTime = stopTime - startTime;

            total += elapsedTime;

            System.out.println("TIME:::::: "+elapsedTime);
        }

        arrayList.add((double)total/runTime);


        /*
        int[] sortedArr = Arrays.copyOf(arr,inputSize);
        Arrays.sort(sortedArr);

        System.out.println("RESULTS ::::::: "+ Arrays.equals(arr,sortedArr));
        */

    }

}
