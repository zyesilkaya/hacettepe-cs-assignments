import java.io.IOException;
import java.util.ArrayList;

public abstract class Manager {

    public static ArrayList<Double> result = new ArrayList<>();
    public static ArrayList<Double> result2 = new ArrayList<>();
    public static ArrayList<Double> result3 = new ArrayList<>();

    public static ArrayList<Double> arrayList;

    public static String fileName;

    int[] inputSizes = {500,1000,2000,4000,8000,16000,32000,64000,128000,250000};

}
